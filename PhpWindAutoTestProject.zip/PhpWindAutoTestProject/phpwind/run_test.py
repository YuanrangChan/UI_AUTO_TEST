import unittest
from phpwind.test_case.models.function import *
#from function import *
#from BSTestRunner import BSTestRunner
import time
from phpwind.common.log import logger

from HTMLTestRunner_jpg import HTMLTestRunner#一般放到Python安装Lib目录下就可以import或from...import导入了
#from phpwind.package import HTMLTestRunner,HTMLTestRunner_jpg,BSTestRunner

report_dir='./test_report'
test_dir='./test_case'

# print("start run test case")
logger.info("开始执行测试用例...")
#discover=unittest.defaultTestLoader.discover(test_dir,pattern="test_login.py")
discover=unittest.defaultTestLoader.discover(test_dir,pattern="test*.py")

#now=time.strftime("%Y-%m-%d %H_%M_%S")
now=time.strftime("%Y-%m-%d %H-%M-%S")
report_name=report_dir+'/'+now+'result.html'

# print("start write report..")
with open(report_name,'wb') as f:
    #runner=BSTestRunner(stream=f,title="Test Report" ,description="localhost login test")
    runner=HTMLTestRunner(stream=f,title="Test Report" ,description="localhost login test")
    runner.run(discover)
    f.close()

# print("start write report..")
logger.info("开始编写测试报告...")

# print("find latest report")
logger.info("查询最新的测试报告...")

latest_report=latest_report(report_dir)

# print("send email report..")
logger.info("通过邮件发送测试报告...")

send_mail(latest_report)

print("Test end")
logger.info("测试结束...")
