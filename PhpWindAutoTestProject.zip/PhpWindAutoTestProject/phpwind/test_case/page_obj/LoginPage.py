from phpwind.test_case.page_obj.BasePage import  *
from selenium.webdriver.common.by import By

class LoginPage(Page):
    # url='/phpwind87/'
    url='/phpwind87/login.php'

    #username_loc=(By.ID,'nav_pwuser')
    username_loc=(By.NAME,'pwuser')
    #password_loc=(By.ID,'showpwd')
    password_loc=(By.NAME,'pwpwd')
    # submit_loc=(By.NAME,'head_login')
    submit_loc=(By.CSS_SELECTOR,'.btn>span>button')

    close_loc=(By.XPATH,".//*[@id='close']")

    def type_username(self,username):
        self.find_element(*self.username_loc).clear()
        self.find_element(*self.username_loc).send_keys(username)

    def type_password(self,password):
        self.find_element(*self.password_loc).clear()
        self.find_element(*self.password_loc).send_keys(password)

    def type_submit(self):
        self.find_element(*self.submit_loc).click()

    def close_tip_window(self):#is_element_exist
        e = self.find_element(*self.close_loc)
        if len(str(e)) > 0:
            print("关闭弹窗！")
            e.click()
        else:
            #pass
            print("没有关闭按钮！")

    # 登录功能模块封装
    def Login_action(self,username,password):
        self.open()
        self.type_username(username)
        self.type_password(password)
        self.type_submit()
        sleep(5)
        # self.close_tip_window()

    loginPass_loc=(By.XPATH,".//*[@id='head']/dl/dd/p[1]/a[1]")#登录成功一定会有退出按钮的
    # loginFail_loc=(By.NAME,'pwuser')
    # loginFail_loc=(By.NAME,'head_login')#没登录成功一定会有登录按钮
    #loginFail_loc=(By.XPATH,".//*[@id='box_container']/div")
    # loginFail_loc=(By.ID,'box_container')
    #账户密码为空会跳转到新的页面
    loginFail_loc=(By.XPATH,".//*[@id='showback']/u")#没登录成功一定会有登录按钮

    def type_loginPass_hint(self):
        return self.find_element(*self.loginPass_loc).text

    def type_loginFail_hint(self):
        return  self.find_element(*self.loginFail_loc).text
        # self.driver.find_element(*self.loginFail_loc).click()
        # t = self.driver.find_element(*self.loginFail_loc).text
        # print(t)
        #return t
    '''
    sleep(3)
d.find_element_by_name("head_login").click()
sleep(1)
d.find_element_by_id("box_container").click()
#t = d.find_element_by_xpath(".//*[@id='box_container']/div/div[2]").click()
#t=d.switch_to_alert()
t = d.find_element_by_id("box_container").text
print(t)
d.quit()

提示
用户名或密码错误,您还可以尝试 4 次
本窗口1秒后关闭
关闭
>>>

其实不是Alert:
吐槽】云-青陌
这不是alert，就是网页内实现的一个模态窗口
【吐槽】云-青陌 2018-9-7 15:29:11
找对应代码就是了
'''
