# -*- coding: utf-8 -*-
# @Time    : 2018/7/15 19:56
# @Author  : David Chan
# @Function: 自动化测试设计模式—PageObject
'''
Page Object是Selenium自动化测试项目开发实践的最佳设计模式之一，
通过对界面元素和功能模块的封装减少冗余代码，同时在后期维护中，若元素定位或功能模块发生变化，
只需要调整页面元素或功能模块封装的代码，提高测试用例的可维护性。
'''
from phpwind.test_case.page_obj.BasePage import  *
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from time import *
import random

class RegisterPage(Page):
    url='/phpwind87/register.php'

    regbutton_loc = (By.ID, 'regbutton')
    regname_loc = (By.ID, 'regname')
    regpwd_loc = (By.NAME, 'regpwd')
    regpwdrepeat_loc = (By.CSS_SELECTOR, '#regpwdrepeat')
    regemail_loc = (By.XPATH, ".//*[@id='regemail']")
    province_loc = (By.ID, 'province_apartment')
    city_loc = (By.CSS_SELECTOR, '#city_apartment')
    # area_loc=(By.ID,'area_apartment')
    area_loc = (By.XPATH, 'html/body/div[3]/div[2]/div/div/div/div[2]/form/div[1]/div/dl[5]/dd[1]/select[3]')
    tiaokuan_loc = (By.ID, 'registerclause')
    submit_loc = (By.CSS_SELECTOR, '.btn>span>button')

    # regname_info_loc = (By.ID, 'regname_info')
    #
    # def get_regname_info_attribute(self):
    #     # self.find_element(*self.regname_info_loc).get_attribute("class")
    #     class1=self.find_element(*self.regname_info_loc).get_attribute("class")
    #     print(class1)

    def click_regbutton(self):
        self.find_element(*self.regbutton_loc).click()

    def type_regname(self, regname):
        self.find_element(*self.regname_loc).clear()
        self.find_element(*self.regname_loc).send_keys(regname)

    def type_regpwd(self, regpwd):
        self.find_element(*self.regpwd_loc).clear()
        self.find_element(*self.regpwd_loc).send_keys(regpwd)

    def type_regpwdrepeat(self, regpwdrepeat):
        self.find_element(*self.regpwdrepeat_loc).clear()
        self.find_element(*self.regpwdrepeat_loc).send_keys(regpwdrepeat)

    def type_regemail(self, regemail):
        self.find_element(*self.regemail_loc).clear()
        self.find_element(*self.regemail_loc).send_keys(regemail)

    def select_province(self):
        # Select(driver.find_element_by_id("province_apartment")).select_by_visible_text(u"L-辽宁省")
        Select(self.find_element(*self.province_loc)).select_by_visible_text(u"G-广东省")
        #Select(self.find_element(*self.province_loc)).select_by_index(list(range(36))
        # Select(driver.find_element_by_id("city_apartment")).select_by_visible_text(u"抚顺市")
        # Select(driver.find_element_by_id("area_apartment")).select_by_visible_text(u"顺城区")

    def select_city(self):
        Select(self.find_element(*self.city_loc)).select_by_visible_text(u"广州市")

    def select_area(self):
        Select(self.find_element(*self.area_loc)).select_by_visible_text(u"越秀区")

    def accept_tk(self):#默认是接受服务协议的，所以不用再去点击(点击就会取消)
        self.find_element(*self.tiaokuan_loc).click()

    def type_submit(self):
        self.find_element(*self.submit_loc).click()

    # 注册功能模块封装
    def Register_action(self, regname, regpwd, regpwdrepeat, regemail):
        self.open()
        self.click_regbutton()
        sleep(3)
        self.type_regname(regname)
        self.type_regpwd(regpwd)
        self.type_regpwdrepeat(regpwdrepeat)
        self.type_regemail(regemail)
        self.select_province()
        self.select_city()
        self.select_area()
        #self.accept_tk()#默认是接受服务协议的，所以不用再去点击(点击就会取消)
        self.type_submit()

    # def Register_action(self):
    #     self.open()
    #     self.click_regbutton()
    #     sleep(3)
    #     #logging.info('======test_user_register======')
    #
    #     regname = 'pw2018' + 'test' + str(random.randint(1000, 9000))
    #     regpwd = 'pwt2018' + str(random.randint(1000, 9000))
    #     #regpwdrepeat = 'pwt2018' + str(random.randint(1000, 9000))
    #     regpwdrepeat = regpwd
    #     regemail = 'pw2018' + str(random.randint(1000, 9000)) + '@183.com'
    #     print(regpwd)
    #     print(regpwdrepeat)
    #     print(regemail)
    #     self.type_regname(regname)
    #     self.type_regpwd(regpwd)
    #     self.type_regpwdrepeat(regpwdrepeat)
    #     self.type_regemail(regemail)
    #     self.select_province()
    #     self.select_city()
    #     self.select_area()
    #     # self.accept_tk()#默认是接受服务协议的，所以不用再去点击(点击就会取消)
    #     self.type_submit()

    RegisterPass_loc=(By.XPATH,".//*[@id='pw_content']/div/div[1]/h5")
    RegisterFail_loc=(By.CSS_SELECTOR,'.f14.mb5')
    #loginFail_loc=(By.XPATH,".//*[@id='box_container']/div")
    #loginFail_loc=(By.ID,'box_container')

    def type_registerPass_hint(self):
        return self.find_element(*self.RegisterPass_loc).text

    def type_registerFail_hint(self):
        return  self.find_element(*self.RegisterFail_loc).text
        #self.driver.find_element(*self.loginFail_loc).click()
        #t = self.driver.find_element(*self.loginFail_loc).text
        #print(t)
        #return t