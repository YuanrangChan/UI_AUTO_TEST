# coding:utf-8
import unittest

class Test1(unittest.TestCase):
    # def setUp(self):
    #     print("start!")
    #
    # def tearDown(self):
    #     print("end!")
    @classmethod
    def setUpClass(cls):
        #print("start!")
        pass

    @classmethod
    def tearDownClass(cls):
        #print("end!")
        pass

    def test_01(self):
        '''判断和相等'''
        a = 1
        b = 2
        self.assertTrue(3, a+b)

    def test_02(self):
        '''判断乘积相等'''
        a = 3
        b = 2
        self.assertTrue(6, a*b)

if __name__ == "__main__":
    unittest.main()
