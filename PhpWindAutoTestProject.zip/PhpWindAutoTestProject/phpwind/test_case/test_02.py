# coding:utf-8
import unittest
from selenium import webdriver
from phpwind.driver.driver import *

class Test1(unittest.TestCase):
    # def setUp(self):
    #     print("start!")
    #     self.driver = browser()
    #     self.driver.get("https://www.baidu.com")
    #     self.driver.implicitly_wait(30)

    # def tearDown(self):
    #     print("end!")
    #     self.driver.close()
    @classmethod
    def setUpClass(cls):
        #print("start!")
        cls.driver = browser()
        cls.driver.get("https://www.baidu.com")
        cls.driver.implicitly_wait(30)

    @classmethod
    def tearDownClass(cls):
        #print("end!")
        cls.driver.quit()

    def test_03(self):
        '''判断属性相同'''
        self.driver.find_element_by_id("kw").send_keys("yoyo")
        value = self.driver.find_element_by_id("kw").get_attribute("value")
        self.assertNotEqual(value,'YOYO')

    def test_04(self):
        '''判断属性相同'''
        self.driver.find_element_by_id("kw").clear()
        self.driver.find_element_by_id("kw").send_keys("haha")
        value = self.driver.find_element_by_id("kw").get_attribute("value")
        self.assertEqual(value,'HAHA')


if __name__ == "__main__":
    unittest.main()
