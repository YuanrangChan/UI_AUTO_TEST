import unittest
from phpwind.test_case.models import function,myunit
from phpwind.test_case.page_obj.LoginPage import *
from time import  sleep

class LoginTest(myunit.StartEnd):
    '''@unittest.skip('skip this case')'''
    def test_login1_normal(self):
        '''用户名密码都正确'''
        '''username and passwd is normal'''
        print("test_login1_normal is start test...")
        po=LoginPage(self.driver)
        #po.Login_action('david','david')
        #po.Login_action('admin','13662219826')#管理员
        po.Login_action('jojo','bean123')#普通用户
        sleep(2)
        po.close_tip_window()

        #self.assertEqual(po.type_loginPass_hint(),'系统设置')#管理员登录才有系统设置
        self.assertEqual(po.type_loginPass_hint(),'退出')
        function.insert_img(self.driver,"phpwind_login1_normal.jpg")
        print("test_login1_normal test end!")

    '''@unittest.skip('skip this case')'''
    def test_login2_PasswdError(self):
        '''用户名正确，密码错误'''
        '''username is ok,passwd is error'''
        print("test_login2_passwdError is start test...")
        po=LoginPage(self.driver)
        po.Login_action('david','david123')
        sleep(5)

        # self.assertEqual(po.type_loginFail_hint(),'')
        # self.assertEqual(po.type_loginFail_hint(),'登录')#没登录成功一定会有登录按钮
        self.assertEqual(po.type_loginFail_hint(),'返回继续操作')#没登录成功-返回继续操作
        function.insert_img(self.driver,"test_login2_PasswdError.jpg")

    def test_login3_empty(self):
        '''用户名密码为空'''
        '''username and passwd is empty'''
        print("test_login3_empty is start test...")
        po=LoginPage(self.driver)
        po.Login_action('','')
        sleep(2)

        self.assertEqual(po.type_loginFail_hint(),'返回继续操作')
        function.insert_img(self.driver,'test_login3_empty.jpg')
        print("test_login3_empty test end")


if __name__ == '__main__':
    unittest.main()

'''@unittest.skip('skip this case')之前是加在用例1,2前

    @unittest.skip('skip this case')
    def test_login2_PasswdError(self):
    '''