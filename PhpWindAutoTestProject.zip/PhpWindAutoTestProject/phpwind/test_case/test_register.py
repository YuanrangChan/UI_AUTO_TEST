import unittest,random
from phpwind.test_case.models import function,myunit
# #将上几级目录设置Mark Directory as –>Source Root后就不需要用绝对路径了
# from models import function,myunit
from phpwind.test_case.page_obj.RegisterPage import *
# from RegisterPage import *
from phpwind.test_case.page_obj.BasePage import  *
from time import  sleep
from selenium.webdriver.common.by import By
from phpwind.driver.driver import browser
# import csv
##==>研究下通过csv，txt文件读取测试数据
# #register = csv.reader(open('F:/PhpWindAutoTestProject/phpwind/data/register.csv'),'r')
# register = csv.reader(open('../data/register.csv','r'))
# register_txt = open('../data/register.txt','r').readlines()
# for line in register_txt:
#     regname=line.split(',')[0]
#     regpwd=line.split(',')[1]
#     regpwdrepeat=line.split(',')[2]
#     regemail=line.split(',')[3]
#     print(regname, regpwd, regpwdrepeat, regemail,end=" ")

class RegisterTest(myunit.StartEnd):
    # '''@unittest.skip('skip this case')'''
    # def test_register_demo(self):
    #     '''username and passwd is normal'''
    #     print("test_register_demo is start test...")
    #     po=RegisterPage(self.driver)
    #     #po.Login_action('david','david')
    #     for line in register_txt:
    #         regname = line.split(',')[0]
    #         regpwd = line.split(',')[1]
    #         regpwdrepeat = line.split(',')[2]
    #         regemail = line.split(',')[3]
    #         print(regname, regpwd, regpwdrepeat, regemail, end=" ")
    #         po.Register_action(regname, regpwd, regpwdrepeat, regemail)
    #         sleep(5)

    '''@unittest.skip('skip this case')'''
    def test_register_success(self):
        '''注册名，密码，确认密码及邮箱符合要求'''
        '''username and passwd is normal'''
        print("test_register_success is start test...")
        po=RegisterPage(self.driver)
        #po.Login_action('david','david')
        #regname = 'pw2018' + 'test' + str(random.randint(1000, 9000)).zfill(4)
        # 会和已经注册的用户重复FourteenTime = strftime('%Y%m%d%H%M%S', localtime(time()))
        #regname = 'test' + str((strftime('%Y%m%d%H%M%S', localtime(time())))[8:])+str(random.randint(10,99))
        regname = 'u' +str(random.randint(10,99999999999))#该字段的值长度要求3-12位(含)
        regpwd = 'pwt2018' + str(random.randint(1000, 9000))
        #regpwdrepeat = 'pwt2018' + str(random.randint(1000, 9000))
        regpwdrepeat = regpwd
        regemail = 'pw2018' + str(random.randint(1000, 9000)) + '@183.com'
        #po.Register_action('david','David123456','David123456','David@phpwind.com')
        po.Register_action(regname, regpwd, regpwdrepeat, regemail)
        #po.Register_action()
        sleep(5)

        self.assertEqual(po.type_registerPass_hint(),'恭喜您完成注册，完善以下信息让您的社区旅途更丰富！')
        #self.assertEqual(po.type_registerPass_hint(),'注册')#这里看到的文本明明是上面的话，而不是"注册"两字，不知为啥？
        function.insert_img(self.driver,"phpwind_register_success.jpg")
        print("test_register_success test end!")

    '''@unittest.skip('skip this case')'''
    def test_register_fail(self):
        '''密码，确认密码不一致'''
        '''username is ok,passwd is error'''
        print("test_register_fail is start test...")
        po=RegisterPage(self.driver)
        #po.Register_action('Smith123','Smith123','smith123','smith@phpwind.com')
        regname = 'pw2018' + 'test' + str(random.randint(1000, 9000))
        regpwd = 'pwt2018' + str(random.randint(1000, 9000))
        regpwdrepeat = 'ppwt2018' + str(random.randint(1000, 9000))#生成的和上面不一样
        regemail = 'pw2018' + str(random.randint(1000, 9000)) + '@183.com'
        po.Register_action(regname, regpwd, regpwdrepeat, regemail)
        sleep(2)

        self.assertEqual(po.type_registerFail_hint(),'已经拥有帐号？')
        function.insert_img(self.driver,"phpwind__register_fail.jpg")
        print("test_register_fail test end...")

    def test_register_empty(self):
        '''注册名，密码，确认密码及邮箱为空'''
        '''one of regname, regpwd, regpwdrepeat, regemail is empty'''
        print("test_register_empty is start test...")
        po=RegisterPage(self.driver)
        po.Register_action('','','','')
        #po.Register_action('','','','')
        #po.Register_action('','','','')
        #po.Register_action('','','','')
        sleep(2)

        self.assertEqual(po.type_registerFail_hint(),'已经拥有帐号？')
        function.insert_img(self.driver,'phpwind__register_empty.jpg')
        print("test_register_empty test end")

    # def test_register_get_attribute(self):
    #     '''get attributes of regname_info, regpwd_info, regpwdrepeat_info, regemail_info,area_apartment_info'''
    '''获取注册信息不合要求时的提示信息（提示信息元素的属性）'''
    #     print("test_register_get_attribute is start test...")
    #     po=RegisterPage(self.driver)
    #     po.Register_action('','','','')
    #     po.accept_tk()#取消勾选我已阅读并完全同意 条款内容
    #     # regname_info_loc = (By.ID, 'regname_info')
    #     # pwd_info_loc = (By.ID, 'pwd_info')
    #     # pwdrepeat_info_loc = (By.ID, 'pwdrepeat_info')
    #     # email_info_loc = (By.ID, "email_info")
    #     # area__loc = (By.ID, 'area_apartment_info')
    #
    #     # def get_regname_info_attribute(self):
    #     #     # self.find_element(*self.regname_info_loc).get_attribute("class")
    #     #     class1=self.find_element(*self.regname_info_loc).get_attribute("class")
    #     #     print(class1)
    #
    #     #class1 = RegisterPage.get_regname_info_attribute
    #     class1 = browser().find_element_by_id("regname_info").get_attribute("class")
    #     # class2 = Page.find_element(*self.pwd_info_loc).get_attribute("class")
    #     # class3 = Page.find_element(*self.pwdrepeat_info_loc).get_attribute("class")
    #     # class4 = Page.find_element(*self.email_info_loc).get_attribute("class")
    #     # class5 = Page.find_element(*self.area__loc).get_attribute("class")
    #     #print(class1, class2, class3, class4, class5)
    #     print(class1)
    #     sleep(2)
    #
    #     self.assertEqual(class1,'用户名不能为空')
    #     function.insert_img(self.driver,'test_register_get_attribute.jpg')
    #     print("test_register_get_attribute test end")


if __name__ == '__main__':
    unittest.main()

'''@unittest.skip('skip this case')之前是加在用例1,2前

    @unittest.skip('skip this case')
    def test_login2_PasswdError(self):
    '''