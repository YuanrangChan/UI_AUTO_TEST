# Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:59:51) [MSC v.1914 64 bit (AMD64)] on win32
# Type "copyright", "credits" or "license()" for more information.
# >>> from selenium import webdriver
# >>> d =webdriver.Firefox()
# >>> d.get("http://localhost:8080/phpwind87/")
# >>> d.get("http://localhost:8080/jenkins/")
# >>> d.get("http://localhost:8080/phpwind87/")
# >>> d.get("http://localhost:8080/phpwind87/")
# >>> d.get("http://localhost:8080/phpwind87/")
# >>> d.get("http://localhost:8080/phpwind87/")
# >>> d.get("http://localhost:8080/phpwind87/")
# >>> d.get("http://localhost:8080/phpwind87/")
# >>> d.get("http://localhost:8080/phpwind87/")
# >>> d.get("http://localhost:8080/jenkins/")
# >>> d.get("http://localhost:8080/jenkins/")
# >>> d.get("http://localhost:8080/phpwind87/")
# >>> d.get("http://localhost:8080/jenkins/")
# >>> d.get("http://localhost:8080/phpwind87/")
# >>> from time import *
# >>> a=str((strftime('%Y%m%d%H%M%S', localtime(time())))[:8])
# >>> a
# '20180909'
# >>> a=str((strftime('%Y%m%d%H%M%S', localtime(time())))[8:])
# >>> a
# '175744'
# >>> a
# '175744'
# >>> d =webdriver.Firefox()
# >>> d.get("http://localhost:8080/phpwind87/register.php#breadCrumb")
# >>> d.find_element_by_id("regname").click()
# >>> print(d.find_element_by_id("regname_info").text)
# 用户名不能为空
# >>> d.find_element_by_id("regname").send_keys("dfg")
# >>> d.find_element_by_id("regname").click()
# >>> print(d.find_element_by_id("regname_info").text)
# 用户名不能为空
# >>> d.find_element_by_id("regname").click()
# >>> d.find_element_by_id("regname").clear()
# >>> d.find_element_by_id("regname").click()
# >>> d.find_element_by_id("regname").clear()
# >>> d.find_element_by_id("regname").send_keys("dfg45552")
# >>> d.find_element_by_css_selector(".btn>span>button").click()
# >>> class1 = driver.find_element_by_id("regname_info").get_attribute("class")
# Traceback (most recent call last):
#   File "<pyshell#35>", line 1, in <module>
#     class1 = driver.find_element_by_id("regname_info").get_attribute("class")
# NameError: name 'driver' is not defined
# >>> class1 = d.find_element_by_id("regname_info").get_attribute("class")
# >>> class2 = d.find_element_by_id("pwd_info").get_attribute("class")
# >>> class3 = d.find_element_by_id("pwdrepeat_info").get_attribute("class")
# >>> class4 = d.find_element_by_id("email_info").get_attribute("class")
# >>> class5 = d.find_element_by_id("area_apartment_info").get_attribute("class")
# >>> class5 = d.find_element_by_id("area_apartment_info").get_attribute("class")
# >>> print(class1,class2,class3,class4,class5)
# correct correct correct correct
# >>> class6 = d.find_element_by_id("regname_info").get_attribute("value")
# >>> print(class6)
# None
# >>> print(class1)
# correct
# >>> print(d.find_element_by_id("regname_info").text())
# Traceback (most recent call last):
#   File "<pyshell#46>", line 1, in <module>
#     print(d.find_element_by_id("regname_info").text())
# TypeError: 'str' object is not callable
# >>> print(d.find_element_by_id("regname_info").text)
# 用户名不能为空
# >>> print(d.find_element_by_id("regname_info").text)
# 用户名不能为空
# >>> print(d.find_element_by_id("regname_info").text)
# 用户名长度错误
# >>> print(d.find_element_by_id("negBar").text)
#
# >>> print(d.find_element_by_id("negBar").text)
#
# >>> print(d.find_element_by_id("passwdRating").text)
# 弱
# >>> print(range(36))
# range(0, 36)
# >>> print(list(range(36)))
# [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]
# >>>