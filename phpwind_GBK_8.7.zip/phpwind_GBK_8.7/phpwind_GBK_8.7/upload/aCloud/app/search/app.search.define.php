<?php
! defined ( 'ACLOUD_PATH' ) && exit ( 'Forbidden' );
define ( 'APP_SEARCH_APPID', '200813330755562391' );
define ( 'APP_SEARCH_HOST', 'cs11.phpwind.com' );


