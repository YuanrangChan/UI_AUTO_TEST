<?php
! defined ( 'ACLOUD_PATH' ) && exit ( 'Forbidden' );
class ACloud_Ver_Config_Dao {
	
	function getConfig() {
		
	}
}