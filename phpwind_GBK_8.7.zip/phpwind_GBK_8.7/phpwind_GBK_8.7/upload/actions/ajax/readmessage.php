<?php
!defined('P_W') && exit('Forbidden');
S::gp(array(
	'mid',
	'type'
));
Showmsg('msg_error');
