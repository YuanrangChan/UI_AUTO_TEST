<?php 
!defined('A_P') && exit('Forbidden');
?>