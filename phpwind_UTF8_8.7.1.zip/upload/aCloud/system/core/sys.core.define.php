<?php
! defined ( 'ACLOUD_PATH' ) && exit ( 'Forbidden' );
define ( 'ACLOUD_V', 'aCloud.v1.0 for phpwind8.7' );
define ( 'ACLOUD_OBJECT_DAO', 'acloud_object_dao' );
define ( 'ACLOUD_VERSION', 'phpwind' );
define ( 'ACLOUD_HTTP_FAIL', '-1' );
define ( 'ACLOUD_HTTP_OK', '0' );
define ( 'ACLOUD_HOST_API', 'api.open.phpwind.com' );
define ( 'ACLOUD_HOST_APP', 'app.open.phpwind.com' );
define ( 'ACLOUD_API_VERSION', 'v1' );
define ( 'ACLOUD_APPLY_SITEURL', '' );
define ( 'ACLOUD_APPLY_CHARSET', '' );
define ( 'ACLOUD_APPLY_IPS', '' );
define ( 'ACLOUD_TABLE_PREFIX', 'pw_' );
define ( 'ACLOUD_XML_VERSION', 'phpwind8.0' );