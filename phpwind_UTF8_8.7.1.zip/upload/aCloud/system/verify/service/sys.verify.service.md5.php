<?php
! defined ( 'ACLOUD_PATH' ) && exit ( 'Forbidden' );
class ACloud_Sys_Verify_Service_MD5 {
	
	public function getFiles() {
		
	}
}