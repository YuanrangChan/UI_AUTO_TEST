<?php
!defined('P_W') && exit('Forbidden');

require_once (R_P . 'require/birth.php');

require_once (R_P . 'require/header.php');
require_once PrintEot('birth');
footer();
