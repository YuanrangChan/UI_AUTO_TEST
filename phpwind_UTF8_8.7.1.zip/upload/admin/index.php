<?php
!function_exists('adminmsg') && exit('Forbidden');

//多种后台布局风格
//if ($_window) {
	require_once (R_P.'admin/windowindex.php'); //豪华桌面版
//} else {
//	require_once (R_P.'admin/simpleindex.php'); //简洁文本版
//}

?>